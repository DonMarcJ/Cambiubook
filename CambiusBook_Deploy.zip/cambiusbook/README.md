# Cambius Book 🗓️
**AI-powered appointment booking for African businesses**
*La vida cambius — Life Transformed*

Built by **Joseph Donn Makwakwa**

---

## 🚀 Deploy to Netlify (Free) — Step by Step

### Step 1 — Install Node.js
Download from https://nodejs.org (choose LTS version) and install it.

### Step 2 — Install dependencies
Open your terminal/command prompt in this folder and run:
```bash
npm install
```

### Step 3 — Test locally (optional but recommended)
```bash
npm start
```
This opens the app at http://localhost:3000

### Step 4 — Build for production
```bash
npm run build
```
This creates a `build/` folder with your production-ready app.

### Step 5 — Deploy on Netlify
1. Go to https://www.netlify.com and sign up free
2. Click **"Add new site"** → **"Deploy manually"**
3. Drag and drop the `build/` folder into Netlify
4. Done! 🎉 You get a free URL like `cambiusbook.netlify.app`

---

## 🌐 Custom Domain (Optional)
1. Buy a domain (e.g. `cambiusbook.com`) from Namecheap (~$10/year)
2. In Netlify → Site settings → Domain management → Add custom domain
3. Follow DNS instructions

---

## 🔑 Important — Anthropic API Key
The AI booking agent uses Claude AI. To make it work in production:

1. Go to https://console.anthropic.com and create an account
2. Generate an API key
3. In Netlify → Site settings → Environment variables → Add:
   - Key: `REACT_APP_ANTHROPIC_KEY`
   - Value: your API key
4. Update `src/App.jsx` line with `callClaude` to use:
   ```js
   "x-api-key": process.env.REACT_APP_ANTHROPIC_KEY
   ```

---

## 📁 Project Structure
```
cambiusbook/
├── public/
│   └── index.html        ← App shell
├── src/
│   ├── App.jsx           ← Main app (all components)
│   └── index.js          ← React entry point
├── netlify.toml          ← Netlify config
├── package.json          ← Dependencies
└── README.md             ← This file
```

---

## 💰 Pricing (Malawian Kwacha)
| Plan | Price |
|------|-------|
| Starter | MWK 15,000/mo |
| Growth | MWK 33,000/mo |
| Pro | MWK 68,000/mo |

---

*© 2025 Cambius Book · La vida cambius*
